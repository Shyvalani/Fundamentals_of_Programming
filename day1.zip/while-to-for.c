int S = 0;
while(num > 0){
    S += num % 10;
    num = num / 10;
}

//
int S;
for(S = 0;num > 0;num = num / 10){
    S += num % 10;    
}







for(int I = 0, J = N-1; I < J ; I++,J--){
    //code
}












